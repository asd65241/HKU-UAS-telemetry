# Converts financial reports in PDF format into cleaned .txt files

__author__ = "you"
__email__ = "your-email"
__all__ = ['tele']

import logging
from telemetry.tele import Drone
